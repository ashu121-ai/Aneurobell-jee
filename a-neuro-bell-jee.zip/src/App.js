
import React, { useState } from "react";

const topics = [
  {
    title: "Projectile Motion",
    video: "https://www.youtube.com/embed/79gS2bF0lJk",
    description: "Understand projectile motion with animation and formulas."
  },
  {
    title: "Ray Optics",
    video: "https://www.youtube.com/embed/1bMcQ0FLVjQ",
    description: "Learn about reflection, refraction with animated ray diagrams."
  },
  {
    title: "Newton's Laws of Motion",
    video: "https://www.youtube.com/embed/kKKM8Y-u7ds",
    description: "Visual explanation of all three laws of motion."
  },
  {
    title: "Work, Energy & Power",
    video: "https://www.youtube.com/embed/AfQx5SOd9qg",
    description: "Concepts of work, energy and power in Hindi + English with examples."
  },
  {
    title: "Laws of Thermodynamics",
    video: "https://www.youtube.com/embed/xGzG_Sy4Hfs",
    description: "Thermodynamics basic to advanced concepts with animation."
  },
  {
    title: "Capacitance",
    video: "https://www.youtube.com/embed/tFFW0Uq1K7Q",
    description: "Understand capacitor circuits with visual learning."
  },
  {
    title: "Electromagnetic Induction",
    video: "https://www.youtube.com/embed/4eFsRQzI4lY",
    description: "Faraday's Law and Lenz's Law with clear visuals."
  },
  {
    title: "Modern Physics",
    video: "https://www.youtube.com/embed/NjSCbMuOQ7k",
    description: "Atomic and nuclear physics with concept clarity."
  }
];

function App() {
  const [search, setSearch] = useState("");

  const filteredTopics = topics.filter(topic =>
    topic.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1 style={{ textAlign: "center" }}>A Neuro Bell – JEE Physics Learning</h1>
      <input
        type="text"
        placeholder="Search Topic..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ width: "100%", padding: "0.5rem", margin: "1rem 0" }}
      />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1rem" }}>
        {filteredTopics.map((topic, index) => (
          <div key={index} style={{ border: "1px solid #ccc", padding: "1rem", borderRadius: "10px" }}>
            <h2>{topic.title}</h2>
            <p>{topic.description}</p>
            <div style={{ position: "relative", paddingBottom: "56.25%", height: 0 }}>
              <iframe
                src={topic.video}
                title={topic.title}
                style={{ position: "absolute", width: "100%", height: "100%" }}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
